//
//  estatistica.swift
//  projetoPokedex
//
//  Created by Mack Aluno on 29/07/25.
//

import SwiftUI

struct estatistica: View {
    var body: some View {
        List {
            Button("Ranking por status"){
                
            }
            Button("Capturados"){
                
            }
        }
    }
}

struct estatistica_Previews: PreviewProvider {
    static var previews: some View {
        estatistica()
    }
}
