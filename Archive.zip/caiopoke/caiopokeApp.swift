//
//  caiopokeApp.swift
//  caiopoke
//
//  Created by Aluno Mack on 31/07/25.
//

import SwiftUI

@main
struct caiopokeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
