//
//  ContentView.swift
//  pokedexSabrina
//
//  Created by Aluno Mack on 30/07/25.
//


import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            PokedexView()
                .tabItem {
                    Label("Pokedex", systemImage: "book.closed")
                }
            
            estatistica()
                .tabItem {
                    Label("Estatística", systemImage: "chart.line.uptrend.xyaxis")
            
                }
            
                .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
