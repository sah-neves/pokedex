//
//  estatistica.swift
//  pokedexSabrina
//
//  Created by Aluno Mack on 30/07/25.
//

import SwiftUI

struct estatistica: View {
    var body: some View {
        List {
            Button("Ranking por status"){
                
            }
            Button("Capturados"){
                
            }
        }
    }
}

struct estatistica_Previews: PreviewProvider {
    static var previews: some View {
        estatistica()
    }
}
